## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval=FALSE--------------------------------------------------------
#  remotes::install_github("ArkajyotiSaha/independencepvalue-project", subdir = "independencepvalue")
#  library(independencepvalue)

## ----classical, echo = FALSE--------------------------------------------------
p <- 6
n <- 9
a <- 0.6
b <- 0.3

Sigma_11 <- QRM::equicorr(p/2, a)
Sigma_22 <- QRM::equicorr(p/2, a)

Sigma <- as.matrix(Matrix::bdiag(Sigma_11, Sigma_22))
Sigma[((p/2+1):p), (1:p/2)] <- b
Sigma[(1:p/2), ((p/2+1):p)] <- b

i0 <- 9768
set.seed(i0)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5)
k1 <- 1

## ----plot, echo = FALSE, fig.height = 5, fig.width = 8, fig.align = "center", dpi = 100----
library(plot.matrix)
par(fig=c(0.01, 0.5, 0, 0.8))
plot(Sigma, breaks=c(0, 1), main="(a) Absolute population correlation", xlab=NA, ylab=NA, col=rev(heat.colors(10)), key=NULL)
par(fig=c(0.51, 1, 0, 0.8),new=TRUE)
plot(abs(cor(X)), breaks=c(0, 1), main="(b) Absolute sample correlation", xlab=NA, ylab=NA, col=rev(heat.colors(10)), key=NULL)
par(fig=c(0, 1, 0, 1),new=TRUE)
rect(
  head(seq(0.85, 5.85, 5/10), -1),
  6.75,
  tail(seq(0.85, 5.85, 5/10), -1),
  7,
  col=rev(heat.colors(10))
)
mtext((1:10)/10, side=3, at=tail(seq(0.85, 5.85, 5/10), -1)-0.25)

