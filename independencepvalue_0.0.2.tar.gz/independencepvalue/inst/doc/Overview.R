## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----classical, echo = FALSE--------------------------------------------------
library(independencepvalue)
p <- 6
n <- 9
Sigma <- create_example(p, a = 0.6, b = 0.3)

i0 <- 9768
set.seed(i0)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5)
k1 <- 1

## ----plot, echo = FALSE, fig.height = 4.5, fig.width = 8, fig.align = "center", dpi = 100----
graphics::par(mfrow=c(1,2))
    graphics::image(t(Sigma)[,ncol(Sigma):1], main="Absolute population correlation", col=rev(grDevices::heat.colors(10)), xaxt='n', yaxt='n')
    graphics::image(t(abs(cor(X)))[,ncol(abs(cor(X))):1], main="Absolute sample correlation", col=rev(grDevices::heat.colors(10)), xaxt='n', yaxt='n')

