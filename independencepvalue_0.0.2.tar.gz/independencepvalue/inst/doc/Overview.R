## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----classical, echo = FALSE--------------------------------------------------
library(independencepvalue)
p <- 6
n <- 9
Sigma <- create_example(p, a = 0.6, b = 0.3)
set.seed(9768)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)

## ----thresholding_alt_overview, echo = FALSE, fig.show='hide'-----------------
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5, fig=TRUE)

## ----classcial_alt_overview, echo = FALSE-------------------------------------
classical_p_val <- classical_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, mc_iter=1000)

## ----selective_alt_overview, echo = FALSE-------------------------------------
selective_p_val <- selective_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, c=0.5, d0=5, mc_iter=1000)

## ----plot, echo = FALSE, fig.height = 4.5, fig.width = 8, fig.align = "center", dpi = 100----
graphics::par(mfrow=c(1,2))
    graphics::image(t(Sigma)[,ncol(Sigma):1], main="Absolute population correlation", col=rev(grDevices::heat.colors(10)), xaxt='n', yaxt='n')
    graphics::image(t(abs(cor(X)))[,ncol(abs(cor(X))):1], main="Absolute sample correlation", col=rev(grDevices::heat.colors(10)), xaxt='n', yaxt='n')

