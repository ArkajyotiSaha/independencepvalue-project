## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE, warning=FALSE--------------------------------------
library(independencepvalue)

## ----simulate_alt-------------------------------------------------------------
p <- 6
n <- 9
Sigma <- create_example(p, a = 0.6, b = 0.3)
set.seed(9768)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)

## ----thresholding_alt, fig.height = 3, fig.width = 9, fig.align = "center", dpi = 100----
block_diag_structure <- block_diag(cor(X), c=0.5, fig = TRUE)
block_diag_structure

## ----classcial_alt------------------------------------------------------------
classical_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, mc_iter=1000)

## ----selective_alt------------------------------------------------------------
selective_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, c=0.5, d0=5, mc_iter=1000)

