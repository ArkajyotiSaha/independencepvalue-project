## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE, warning=FALSE--------------------------------------
library(independencepvalue)

## ----gen_nul------------------------------------------------------------------
n <- 9
p <- 6
Sigma <- diag(p)
i0 <- 9768
set.seed(i0)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)

## ----thresholding_null, fig.height = 3, fig.width = 9, fig.align = "center", dpi = 100----
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5, fig = TRUE)
block_diag_structure

## ----selective_null-----------------------------------------------------------
independencepvalue::selective_p_val(S=cov(X), CP=block_diag_structure, k=3, n=n, c=0.5, d0=5, mc_iter=1000)

## ----simulate_alt-------------------------------------------------------------
p <- 6
n <- 9
Sigma <- create_example(p = p, a = 0.6, b = 0.3)

set.seed(i0)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)

## ----thresholding_alt, fig.height = 3, fig.width = 9, fig.align = "center", dpi = 100----
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5, fig = TRUE)
block_diag_structure

## ----classcial_alt------------------------------------------------------------
set.seed(i0)
independencepvalue::classical_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, mc_iter=1000)

## ----selective_alt------------------------------------------------------------
independencepvalue::selective_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, c=0.5, d0=5, mc_iter=1000)

