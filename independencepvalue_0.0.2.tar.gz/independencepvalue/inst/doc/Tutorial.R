## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE, warning=FALSE--------------------------------------
library(independencepvalue)
library(MASS)
library(Matrix)
library(QRM)

## ----gen_nul------------------------------------------------------------------
n <- 9
p <- 6
Sigma <- diag(p)
set.seed(123)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)

## ----heatmap_null, fig.height = 5, fig.width = 8, fig.align = "center", dpi = 100----
library(plot.matrix)
par(fig=c(0.01, 0.5, 0, 0.8))
plot(Sigma, breaks=c(0, 1), main="(a) Absolute population correlation", xlab=NA, ylab=NA, col=rev(heat.colors(10)), key=NULL)
par(fig=c(0.51, 1, 0, 0.8),new=TRUE)
plot(abs(cor(X)), breaks=c(0, 1), main="(b) Absolute sample correlation", xlab=NA, ylab=NA, col=rev(heat.colors(10)), key=NULL)
par(fig=c(0, 1, 0, 1),new=TRUE)
rect(
  head(seq(0.85, 5.85, 5/10), -1),
  6.75,
  tail(seq(0.85, 5.85, 5/10), -1),
  7,
  col=rev(heat.colors(10))
)
mtext((1:10)/10, side=3, at=tail(seq(0.85, 5.85, 5/10), -1)-0.25)

## ----thresholding_null--------------------------------------------------------
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5)
block_diag_structure

## ----selective_null-----------------------------------------------------------
set.seed(123)
select_p_val_null <- independencepvalue::selective_p_val(S=cov(X), CP=block_diag_structure, k=4, n=n, c=0.5, d0=5, mc_iter=1000)
select_p_val_null

## ----simulate_alt-------------------------------------------------------------
p <- 6
n <- 9
a <- 0.6
b <- 0.3

Sigma_11 <- QRM::equicorr(p/2, a)
Sigma_22 <- QRM::equicorr(p/2, a)

Sigma <- as.matrix(Matrix::bdiag(Sigma_11, Sigma_22))
Sigma[((p/2+1):p), (1:p/2)] <- b
Sigma[(1:p/2), ((p/2+1):p)] <- b

i0 <- 9768
set.seed(i0)
X <- MASS::mvrnorm(n=n, rep(0, p), Sigma)

## ----plot_alt, fig.height = 5, fig.width = 8, fig.align = "center", dpi = 100----
library(plot.matrix)
par(fig=c(0.01, 0.5, 0, 0.8))
plot(Sigma, breaks=c(0, 1), main="(a) Absolute population correlation", xlab=NA, ylab=NA, col=rev(heat.colors(10)), key=NULL)
par(fig=c(0.51, 1, 0, 0.8),new=TRUE)
plot(abs(cor(X)), breaks=c(0, 1), main="(b) Absolute sample correlation", xlab=NA, ylab=NA, col=rev(heat.colors(10)), key=NULL)
par(fig=c(0, 1, 0, 1),new=TRUE)
rect(
  head(seq(0.85, 5.85, 5/10), -1),
  6.75,
  tail(seq(0.85, 5.85, 5/10), -1),
  7,
  col=rev(heat.colors(10))
)
mtext((1:10)/10, side=3, at=tail(seq(0.85, 5.85, 5/10), -1)-0.25)

## ----thresholding_alt---------------------------------------------------------
block_diag_structure <- independencepvalue::block_diag(cor(X), c=0.5)
block_diag_structure

## ----classcial_alt------------------------------------------------------------
set.seed(i0)
classical_p_val_alt <- independencepvalue::classical_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, mc_iter=1000)
classical_p_val_alt

## ----selective_alt------------------------------------------------------------
set.seed(123)
select_p_val_alt <- independencepvalue::selective_p_val(S=cov(X), CP=block_diag_structure, k=1, n=n, c=0.5, d0=5, mc_iter=1000)
select_p_val_alt

